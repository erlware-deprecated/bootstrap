-module(make_rel).

-export([make_rel/0]).

make_rel() ->
	EbinDirs = filelib:wildcard("../../lib/*/ebin"),
	[code:add_patha(EbinDir) || EbinDir <- EbinDirs],
	systools:make_script("faxien", [local]).
